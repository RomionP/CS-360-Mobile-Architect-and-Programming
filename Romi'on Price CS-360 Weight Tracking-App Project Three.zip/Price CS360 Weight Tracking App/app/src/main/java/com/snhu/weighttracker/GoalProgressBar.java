package com.snhu.weighttracker;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

/**
 * Progress bar with the goal marked in the middle.
 *
 *   start ─────────── GOAL ─────────── overshoot
 *   [ orange fill → ]  |
 *   [ red fill ──────────────→ ]        (once you pass the goal)
 *
 * Left half  = progress from the first weigh-in toward the goal (orange).
 * Right half = how far past the goal you've gone; the whole bar turns red.
 */
public class GoalProgressBar extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint markerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private final int colorProgress;
    private final int colorOver;
    private final float trackHeight;
    private final float markerWidth;

    /**
     * -1..0 is unused; 0..1 = progress toward the goal (left half);
     * 1..2 = past the goal (right half). Animated.
     */
    private float position = 0f;
    private ValueAnimator animator;

    public GoalProgressBar(Context context) { this(context, null); }

    public GoalProgressBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        float dp = getResources().getDisplayMetrics().density;
        trackHeight = 8 * dp;
        markerWidth = 3 * dp;
        colorProgress = ContextCompat.getColor(context, R.color.coral_500);
        colorOver = ContextCompat.getColor(context, R.color.danger);
        trackPaint.setColor(ContextCompat.getColor(context, R.color.teal_200));
        markerPaint.setColor(ContextCompat.getColor(context, R.color.white));
    }

    /**
     * @param towardGoal 0..1 share of the distance to the goal already covered
     * @param pastGoal   0..1 how far beyond the goal (as a share of the original
     *                   distance); 0 if the goal hasn't been passed
     */
    public void setProgress(float towardGoal, float pastGoal, boolean animate) {
        float target = pastGoal > 0f
                ? 1f + clamp(pastGoal)
                : clamp(towardGoal);
        if (animator != null) animator.cancel();
        if (!animate) {
            position = target;
            invalidate();
            return;
        }
        animator = ValueAnimator.ofFloat(position, target);
        animator.setDuration(450);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(a -> {
            position = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    public boolean isPastGoal() { return position > 1f; }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int h = (int) (getResources().getDisplayMetrics().density * 18)
                + getPaddingTop() + getPaddingBottom();
        setMeasuredDimension(getDefaultSize(getSuggestedMinimumWidth(), widthMeasureSpec),
                resolveSize(h, heightMeasureSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float left = getPaddingLeft();
        float right = getWidth() - getPaddingRight();
        float width = right - left;
        float centerX = left + width / 2f;
        float cy = getHeight() / 2f;
        float r = trackHeight / 2f;

        // Track
        rect.set(left, cy - r, right, cy + r);
        canvas.drawRoundRect(rect, r, r, trackPaint);

        // Fill: up to the middle while approaching, past the middle once over.
        float fillEnd = left + (position / 2f) * width;
        if (fillEnd > left + 0.5f) {
            fillPaint.setColor(position > 1f ? colorOver : colorProgress);
            rect.set(left, cy - r, Math.min(fillEnd, right), cy + r);
            canvas.drawRoundRect(rect, r, r, fillPaint);
        }

        // Goal marker in the middle, slightly taller than the track.
        float half = markerWidth / 2f;
        rect.set(centerX - half, 0, centerX + half, getHeight());
        canvas.drawRoundRect(rect, half, half, markerPaint);
    }

    private static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
}

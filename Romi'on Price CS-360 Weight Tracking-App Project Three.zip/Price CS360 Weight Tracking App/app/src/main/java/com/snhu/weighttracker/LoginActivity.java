package com.snhu.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Screen 1: Login.
 * Checks the username/password against UserDatabase. New users go to CreateAccountActivity.
 */
public class LoginActivity extends AppCompatActivity {

    private TextInputLayout layoutUsername, layoutPassword;
    private TextInputEditText editUsername, editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        layoutUsername = findViewById(R.id.layoutUsername);
        layoutPassword = findViewById(R.id.layoutPassword);
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        MaterialButton buttonLogin = findViewById(R.id.buttonLogin);
        MaterialButton buttonCreate = findViewById(R.id.buttonCreateAccount);
        MaterialButton buttonGuest = findViewById(R.id.buttonGuest);

        // "Done" on the keyboard submits, matching the focus order.
        editPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                buttonLogin.performClick();
                return true;
            }
            return false;
        });

        buttonLogin.setOnClickListener(v -> {
            if (!validate()) return;
            String username = text(editUsername);
            UserDatabase db = UserDatabase.get(this);

            // Only accounts that were created (and saved) can log in.
            if (!db.userExists(username)) {
                showError(layoutUsername, editUsername, getString(R.string.error_no_account));
                return;
            }
            if (!db.checkLogin(username, rawPassword())) {
                editPassword.setText("");
                showError(layoutPassword, editPassword, getString(R.string.error_wrong_password));
                return;
            }
            Session.login(this, db.getUserId(username), username);
            // Every login goes through the SMS screen before the dashboard.
            Intent i = new Intent(this, SmsPermissionActivity.class);
            i.putExtra(SmsPermissionActivity.EXTRA_ONBOARDING, true);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        });

        // Account creation has its own page; carry over any username already typed.
        buttonCreate.setOnClickListener(v -> {
            Intent i = new Intent(this, CreateAccountActivity.class);
            i.putExtra(CreateAccountActivity.EXTRA_USERNAME, text(editUsername));
            startActivity(i);
        });

        // Guest mode: no sign-in, nothing saved. Skips the SMS screen (texts
        // need a saved phone number) and goes straight to the dashboard.
        buttonGuest.setOnClickListener(v -> {
            Session.startGuest(this);
            Toast.makeText(this, R.string.msg_guest_started, Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, WeightGridActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        });
    }

    /** Shows inline errors on empty fields. */
    private boolean validate() {
        boolean ok = true;
        layoutUsername.setError(null);
        layoutPassword.setError(null);
        if (TextUtils.isEmpty(text(editUsername))) {
            layoutUsername.setError(getString(R.string.error_username_required));
            ok = false;
        }
        if (TextUtils.isEmpty(text(editPassword))) {
            layoutPassword.setError(getString(R.string.error_password_required));
            ok = false;
        }
        if (!ok) {
            boolean userMissing = TextUtils.isEmpty(text(editUsername));
            showError(userMissing ? layoutUsername : layoutPassword,
                    userMissing ? editUsername : editPassword,
                    getString(userMissing ? R.string.error_username_required
                                          : R.string.error_password_required));
        }
        return ok;
    }

    /**
     * Shows an error under the field AND as a pop-up message, then scrolls to the field.
     * The buttons sit lower on the screen than the fields, so an inline error alone
     * can be hidden by the keyboard or scrolled out of view.
     */
    private void showError(TextInputLayout layout, TextInputEditText field, String message) {
        layout.setError(message);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(field.getWindowToken(), 0);
        field.requestFocus();
        layout.getParent().requestChildFocus(layout, layout);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    /** Password exactly as typed (spaces are not trimmed off passwords). */
    private String rawPassword() {
        return editPassword.getText() == null ? "" : editPassword.getText().toString();
    }

    private static String text(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }
}

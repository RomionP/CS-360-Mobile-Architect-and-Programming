package com.snhu.weighttracker;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * Screen 2c: read-only list of every logged weight with its date,
 * grouped by month (newest first). Opened from the grid's toolbar.
 */
public class LoggedWeightsActivity extends AppCompatActivity {

    private static final DateTimeFormatter RANGE_FMT =
            DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Session.requireLogin(this)) return;
        setContentView(R.layout.activity_logged_weights);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        // Only the logged-in account's weigh-ins (or the guest's unsaved ones).
        List<WeightEntry> entries = WeightRepository.getEntries(this);

        TextView textCount = findViewById(R.id.textCount);
        TextView textRange = findViewById(R.id.textRange);
        textCount.setText(getResources().getQuantityString(
                R.plurals.logged_count, entries.size(), entries.size()));

        if (entries.isEmpty()) {
            textRange.setText("—");
            findViewById(R.id.emptyLogged).setVisibility(View.VISIBLE);
            return;
        }

        // List is newest-first: last item is the oldest weigh-in.
        String oldest = entries.get(entries.size() - 1).getDate().format(RANGE_FMT);
        String newest = entries.get(0).getDate().format(RANGE_FMT);
        textRange.setText(getString(R.string.logged_range, oldest, newest));

        RecyclerView recycler = findViewById(R.id.recyclerLogged);
        recycler.setAdapter(new LoggedWeightsAdapter(entries));
    }
}

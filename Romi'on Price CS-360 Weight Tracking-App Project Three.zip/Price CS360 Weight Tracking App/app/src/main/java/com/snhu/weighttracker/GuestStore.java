package com.snhu.weighttracker;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Guest mode's data: held in memory only, never written to the database,
 * SharedPreferences, or any file. It is wiped when the guest exits, when
 * someone logs in, when a new guest session starts, or when Android ends
 * the app's process.
 */
final class GuestStore {

    private static final List<WeightEntry> entries = new ArrayList<>();
    private static double goal = UserDatabase.DEFAULT_GOAL;
    private static long nextId = 1;

    private GuestStore() { }

    static synchronized void clear() {
        entries.clear();
        goal = UserDatabase.DEFAULT_GOAL;
        nextId = 1;
    }

    /** Copy of the guest's weigh-ins, newest first. */
    static synchronized List<WeightEntry> getWeights() {
        return new ArrayList<>(entries);
    }

    static synchronized long addWeight(LocalDate date, double weight) {
        long id = nextId++;
        insertSorted(new WeightEntry(id, date, weight));
        return id;
    }

    /** Replaces a weigh-in's date and weight, keeping its id. */
    static synchronized boolean updateWeight(long id, LocalDate date, double weight) {
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).getId() == id) {
                entries.remove(i);
                insertSorted(new WeightEntry(id, date, weight));   // date may have moved
                return true;
            }
        }
        return false;
    }

    static synchronized void deleteWeight(long id) {
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).getId() == id) { entries.remove(i); return; }
        }
    }

    /** Same order as the database query: date DESC, then id DESC. */
    private static void insertSorted(WeightEntry entry) {
        int pos = 0;
        while (pos < entries.size() && isNewerOrSame(entries.get(pos), entry)) pos++;
        entries.add(pos, entry);
    }

    private static boolean isNewerOrSame(WeightEntry existing, WeightEntry entry) {
        if (existing.getDate().isAfter(entry.getDate())) return true;
        return existing.getDate().isEqual(entry.getDate()) && existing.getId() > entry.getId();
    }

    static synchronized double getGoal() { return goal; }

    static synchronized void setGoal(double g) { goal = g; }
}

package com.snhu.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/**
 * Binds WeightEntry rows to item_weight_row.xml. Rows are newest-first.
 * Tapping a row edits it; the trash button deletes it.
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.RowHolder> {

    public interface OnDeleteListener {
        void onDelete(int position, WeightEntry entry);
    }

    public interface OnEditListener {
        void onEdit(WeightEntry entry);
    }

    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.getDefault());

    private final List<WeightEntry> entries;
    private final OnDeleteListener deleteListener;
    private final OnEditListener editListener;

    public WeightAdapter(List<WeightEntry> entries, OnDeleteListener deleteListener,
                         OnEditListener editListener) {
        this.entries = entries;
        this.deleteListener = deleteListener;
        this.editListener = editListener;
    }

    @NonNull
    @Override
    public RowHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_row, parent, false);
        return new RowHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RowHolder h, int position) {
        WeightEntry e = entries.get(position);
        String date = e.getDate().format(DATE_FMT);
        h.date.setText(date);
        h.weight.setText(String.format(Locale.getDefault(), "%.1f", e.getWeight()));

        // Change vs. the previous (older) entry, which is the next row down.
        if (position + 1 < entries.size()) {
            double diff = e.getWeight() - entries.get(position + 1).getWeight();
            int color = diff <= 0 ? R.color.success : R.color.danger;
            h.change.setText(String.format(Locale.getDefault(), "%s%.1f",
                    diff > 0 ? "+" : (diff < 0 ? "−" : ""), Math.abs(diff)));
            h.change.setTextColor(ContextCompat.getColor(h.itemView.getContext(), color));
        } else {
            h.change.setText("—");
            h.change.setTextColor(ContextCompat.getColor(h.itemView.getContext(), R.color.ink_600));
        }

        // Alternate row shading improves scanability of the grid.
        h.itemView.setBackgroundColor(ContextCompat.getColor(h.itemView.getContext(),
                position % 2 == 0 ? R.color.surface : R.color.row_alt));

        // Tap anywhere on the row (except the trash button) to edit it.
        h.itemView.setContentDescription(
                h.itemView.getContext().getString(R.string.cd_edit_row, date));
        h.itemView.setOnClickListener(v -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) editListener.onEdit(entries.get(pos));
        });

        h.delete.setContentDescription(
                h.itemView.getContext().getString(R.string.cd_delete_row, date));
        h.delete.setOnClickListener(v -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) {
                deleteListener.onDelete(pos, entries.get(pos));
            }
        });
    }

    @Override
    public int getItemCount() { return entries.size(); }

    static class RowHolder extends RecyclerView.ViewHolder {
        final TextView date, weight, change;
        final ImageButton delete;

        RowHolder(@NonNull View v) {
            super(v);
            date = v.findViewById(R.id.textDate);
            weight = v.findViewById(R.id.textWeight);
            change = v.findViewById(R.id.textChange);
            delete = v.findViewById(R.id.buttonDelete);
        }
    }
}

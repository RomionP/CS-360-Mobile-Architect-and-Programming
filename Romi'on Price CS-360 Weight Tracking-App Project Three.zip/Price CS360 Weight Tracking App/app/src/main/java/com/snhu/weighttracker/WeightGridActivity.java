package com.snhu.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import android.widget.TextView;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Screen 2: the user's weight history displayed as a grid, with a goal summary.
 * All four database actions start here:
 *   Create - "Add Weight" button        Read   - the grid itself
 *   Update - tap a row / "Edit goal"    Delete - trash button on a row (with Undo)
 * Data goes through WeightRepository (database for accounts, memory for guests).
 */
public class WeightGridActivity extends AppCompatActivity {

    /** The current user's weigh-ins (newest first): database for accounts, memory for guests. */
    private final List<WeightEntry> entries = new ArrayList<>();
    private WeightAdapter adapter;
    private RecyclerView recycler;
    private View emptyState;
    private TextView textCurrent, textGoal, textToGo;
    private GoalProgressBar progressGoal;

    private double goalWeight = UserDatabase.DEFAULT_GOAL;

    /** Receives the new row from AddWeightActivity. */
    private final ActivityResultLauncher<Intent> addWeightLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                Intent d = result.getData();
                LocalDate date = LocalDate.ofEpochDay(d.getLongExtra(AddWeightActivity.EXTRA_DATE_EPOCH_DAY, 0));
                double weight = d.getDoubleExtra(AddWeightActivity.EXTRA_WEIGHT, 0);
                long id = WeightRepository.addWeight(this, date, weight);   // guests: memory only
                if (id != -1) addEntry(new WeightEntry(id, date, weight));
            });

    /** Receives the changed row from AddWeightActivity (edit mode). */
    private final ActivityResultLauncher<Intent> editWeightLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                Intent d = result.getData();
                long id = d.getLongExtra(AddWeightActivity.EXTRA_ENTRY_ID, -1);
                LocalDate date = LocalDate.ofEpochDay(d.getLongExtra(AddWeightActivity.EXTRA_DATE_EPOCH_DAY, 0));
                double weight = d.getDoubleExtra(AddWeightActivity.EXTRA_WEIGHT, 0);
                if (id != -1 && WeightRepository.updateWeight(this, id, date, weight)) {
                    onEntryUpdated(id);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Session.requireLogin(this)) return;
        setContentView(R.layout.activity_weight_grid);

        // Load only this account's data (or the guest's unsaved data).
        boolean guest = Session.isGuest();
        entries.addAll(WeightRepository.getEntries(this));
        goalWeight = WeightRepository.getGoal(this);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setSubtitle(guest ? getString(R.string.guest_subtitle) : Session.username(this));
        toolbar.inflateMenu(R.menu.menu_grid);
        if (guest) {
            // SMS texts need a saved phone number, so they're for accounts only.
            toolbar.getMenu().findItem(R.id.action_sms).setVisible(false);
            toolbar.getMenu().findItem(R.id.action_settings).setVisible(false);
            toolbar.getMenu().findItem(R.id.action_logout).setTitle(R.string.menu_exit_guest);
        }
        toolbar.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.action_logged_weights) {
                startActivity(new Intent(this, LoggedWeightsActivity.class));
                return true;
            } else if (item.getItemId() == R.id.action_sms) {
                startActivity(new Intent(this, SmsPermissionActivity.class));
                return true;
            } else if (item.getItemId() == R.id.action_settings) {
                startActivity(new Intent(this, SettingsActivity.class));
                return true;
            } else if (item.getItemId() == R.id.action_logout) {
                if (guest && !entries.isEmpty()) confirmExitGuest(); else logout();
                return true;
            }
            return false;
        });

        textCurrent = findViewById(R.id.textCurrentWeight);
        textGoal = findViewById(R.id.textGoalWeight);
        textToGo = findViewById(R.id.textToGo);
        progressGoal = findViewById(R.id.progressGoal);
        emptyState = findViewById(R.id.emptyState);
        recycler = findViewById(R.id.recyclerWeights);

        adapter = new WeightAdapter(entries, this::deleteEntry, this::editEntry);
        recycler.setAdapter(adapter);

        // Collapse the FAB label while scrolling so it never hides grid rows.
        ExtendedFloatingActionButton fab = findViewById(R.id.fabAddWeight);
        recycler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView rv, int dx, int dy) {
                if (dy > 0) fab.shrink(); else if (dy < 0) fab.extend();
            }
        });
        fab.setOnClickListener(v ->
                addWeightLauncher.launch(new Intent(this, AddWeightActivity.class)));

        findViewById(R.id.buttonEditGoal).setOnClickListener(v -> showGoalDialog());

        refreshSummary();
    }

    private void logout() {
        Session.logout(this);   // for a guest, this also wipes the unsaved data
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    /** Guests are warned before their unsaved weigh-ins are thrown away. */
    private void confirmExitGuest() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.guest_exit_title)
                .setMessage(R.string.guest_exit_message)
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton(R.string.guest_exit_confirm, (d, w) -> logout())
                .show();
    }

    private void addEntry(WeightEntry entry) {
        // Keep newest-first order.
        int pos = 0;
        while (pos < entries.size() && entries.get(pos).getDate().isAfter(entry.getDate())) pos++;
        entries.add(pos, entry);
        adapter.notifyItemInserted(pos);
        adapter.notifyItemRangeChanged(pos, entries.size() - pos);
        recycler.scrollToPosition(pos);
        refreshSummary();

        // Newest weigh-in is exactly the goal weight -> celebrate, and send the
        // goal-reached SMS (only if the user granted permission). Going past the
        // goal without landing on it does not count.
        if (pos == 0 && justReachedGoal()) {
            showGoalReached();
            SmsNotifier.sendGoalReached(this, goalWeight);
        }
    }

    /**
     * True only when the newest weigh-in is exactly the goal weight (e.g. 170.0
     * with a 170.0 goal). Passing the goal without landing on it (e.g. 175 -> 169)
     * does NOT count. If the weigh-in before it was already exactly at the goal,
     * the message isn't repeated.
     */
    private boolean justReachedGoal() {
        double latest = entries.get(0).getWeight();
        if (!isAtGoal(latest)) return false;
        if (entries.size() == 1) return true;                     // very first weigh-in
        return !isAtGoal(entries.get(1).getWeight());             // not already there
    }

    /**
     * Exact match at one decimal place (how weights are entered and shown).
     * Rounding to tenths avoids floating-point noise, so 170.0 matches a 170 goal
     * but 169.9 and 170.1 do not.
     */
    private boolean isAtGoal(double weight) {
        return Math.round(weight * 10) == Math.round(goalWeight * 10);
    }

    private void showGoalReached() {
        new MaterialAlertDialogBuilder(this)
                .setIcon(R.drawable.ic_flag)
                .setTitle(R.string.goal_reached_title)
                .setMessage(getString(R.string.goal_reached_message, goalWeight))
                .setPositiveButton(R.string.goal_reached_ok, null)
                .show();
    }

    /** Opens the weigh-in form pre-filled with this row's values. */
    private void editEntry(WeightEntry entry) {
        Intent i = new Intent(this, AddWeightActivity.class);
        i.putExtra(AddWeightActivity.EXTRA_ENTRY_ID, entry.getId());
        i.putExtra(AddWeightActivity.EXTRA_DATE_EPOCH_DAY, entry.getDate().toEpochDay());
        i.putExtra(AddWeightActivity.EXTRA_WEIGHT, entry.getWeight());
        editWeightLauncher.launch(i);
    }

    /**
     * Reloads the grid after an edit (a changed date can move the row), then
     * celebrates if the edited row is now the newest one and is exactly the goal.
     */
    private void onEntryUpdated(long id) {
        entries.clear();
        entries.addAll(WeightRepository.getEntries(this));
        adapter.notifyDataSetChanged();
        refreshSummary();
        Snackbar.make(findViewById(R.id.rootGrid), R.string.msg_entry_updated, Snackbar.LENGTH_SHORT)
                .setAnchorView(R.id.fabAddWeight)
                .show();

        if (!entries.isEmpty() && entries.get(0).getId() == id && justReachedGoal()) {
            showGoalReached();
            SmsNotifier.sendGoalReached(this, goalWeight);
        }
    }

    private void deleteEntry(int position, WeightEntry entry) {
        entries.remove(position);
        WeightRepository.deleteWeight(this, entry.getId());
        adapter.notifyItemRemoved(position);
        adapter.notifyItemRangeChanged(Math.max(0, position - 1), entries.size());
        refreshSummary();

        Snackbar.make(findViewById(R.id.rootGrid), R.string.msg_entry_deleted, Snackbar.LENGTH_LONG)
                .setAnchorView(R.id.fabAddWeight)
                .setAction(R.string.action_undo, v -> {
                    // Put it back in the database (it gets a new id).
                    long id = WeightRepository.addWeight(this, entry.getDate(), entry.getWeight());
                    if (id == -1) return;
                    entries.add(position, new WeightEntry(id, entry.getDate(), entry.getWeight()));
                    adapter.notifyItemInserted(position);
                    adapter.notifyItemRangeChanged(position, entries.size() - position);
                    refreshSummary();
                })
                .show();
    }

    private void showGoalDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_goal, null);
        TextInputEditText edit = view.findViewById(R.id.editGoal);
        edit.setText(String.format(Locale.US, "%.1f", goalWeight));
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.dialog_goal_title)
                .setIcon(R.drawable.ic_flag)
                .setView(view)
                .setNegativeButton(R.string.action_cancel, null)
                .setPositiveButton(R.string.action_save, (d, w) -> {
                    try {
                        goalWeight = Double.parseDouble(String.valueOf(edit.getText()));
                        WeightRepository.setGoal(this, goalWeight);   // each account keeps its own goal
                        refreshSummary();
                    } catch (NumberFormatException ignored) { }
                })
                .show();
    }

    private void refreshSummary() {
        boolean empty = entries.isEmpty();
        emptyState.setVisibility(empty ? View.VISIBLE : View.GONE);
        textGoal.setText(getString(R.string.unit_lbs, goalWeight));

        if (empty) {
            textCurrent.setText("—");
            textToGo.setText("—");
            progressGoal.setProgress(0f, 0f, false);
            progressGoal.setContentDescription(null);
            return;
        }
        double current = entries.get(0).getWeight();
        // Pounds left to reach the goal: "-" = still to lose (goal below current),
        // "+" = still to gain (goal above current).
        double toGo = Math.abs(current - goalWeight);
        String sign = toGo < 0.05 ? "" : (goalWeight < current ? "-" : "+");
        textCurrent.setText(getString(R.string.unit_lbs, current));
        textToGo.setText(getString(R.string.unit_lbs_signed, sign, toGo));

        // Bar runs from 0 lbs (left end) to the goal (middle marker) to twice the
        // goal (right end). Fill = current weight on that scale; anything past
        // the goal fills beyond the middle and turns red.
        double fraction = goalWeight > 0 ? current / goalWeight : 0;
        float toward = (float) Math.max(0, Math.min(1, fraction));
        float past = (float) Math.max(0, fraction - 1);
        progressGoal.setProgress(toward, past, true);
        progressGoal.setContentDescription(past > 0
                ? getString(R.string.cd_progress_over, toGo)
                : getString(R.string.cd_progress, Math.round(toward * 100)));
    }
}

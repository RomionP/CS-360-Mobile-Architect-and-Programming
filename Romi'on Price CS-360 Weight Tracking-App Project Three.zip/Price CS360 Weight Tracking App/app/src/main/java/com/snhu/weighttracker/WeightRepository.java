package com.snhu.weighttracker;

import android.content.Context;

import java.time.LocalDate;
import java.util.List;

/**
 * Single place screens go for weight data. Logged-in accounts read and write
 * UserDatabase (saved per account); guests read and write GuestStore, which
 * lives in memory only and is never saved.
 */
public final class WeightRepository {

    private WeightRepository() { }

    /** The current user's weigh-ins, newest first. */
    public static List<WeightEntry> getEntries(Context context) {
        if (Session.isGuest()) return GuestStore.getWeights();
        return UserDatabase.get(context).getWeights(Session.userId(context));
    }

    /** @return the new entry's id, or -1 on failure. */
    public static long addWeight(Context context, LocalDate date, double weight) {
        if (Session.isGuest()) return GuestStore.addWeight(date, weight);
        return UserDatabase.get(context).addWeight(Session.userId(context), date, weight);
    }

    /** @return true if the weigh-in was found and changed. */
    public static boolean updateWeight(Context context, long id, LocalDate date, double weight) {
        if (Session.isGuest()) return GuestStore.updateWeight(id, date, weight);
        return UserDatabase.get(context).updateWeight(Session.userId(context), id, date, weight);
    }

    public static void deleteWeight(Context context, long id) {
        if (Session.isGuest()) { GuestStore.deleteWeight(id); return; }
        UserDatabase.get(context).deleteWeight(Session.userId(context), id);
    }

    public static double getGoal(Context context) {
        if (Session.isGuest()) return GuestStore.getGoal();
        return UserDatabase.get(context).getGoal(Session.userId(context));
    }

    public static void setGoal(Context context, double goal) {
        if (Session.isGuest()) { GuestStore.setGoal(goal); return; }
        UserDatabase.get(context).setGoal(Session.userId(context), goal);
    }
}

package com.snhu.weighttracker;

import java.time.LocalDate;

/** One weigh-in: one row of the weight grid and one row of the database's weights table. */
public class WeightEntry {
    private final long id;
    private final LocalDate date;
    private final double weight;

    public WeightEntry(long id, LocalDate date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() { return id; }
    public LocalDate getDate() { return date; }
    public double getWeight() { return weight; }
}

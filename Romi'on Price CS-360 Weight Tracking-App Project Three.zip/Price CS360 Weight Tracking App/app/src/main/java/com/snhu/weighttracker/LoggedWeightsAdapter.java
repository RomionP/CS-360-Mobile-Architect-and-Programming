package com.snhu.weighttracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Shows logged weights newest-first, with a heading at the start of each month.
 * Rows are either a month heading (YearMonth) or a weigh-in (WeightEntry).
 */
public class LoggedWeightsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_MONTH = 0;
    private static final int TYPE_ENTRY = 1;

    private static final DateTimeFormatter MONTH_FMT =
            DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault());
    private static final DateTimeFormatter FULL_FMT =
            DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.getDefault());
    private static final DateTimeFormatter WEEKDAY_FMT =
            DateTimeFormatter.ofPattern("EEE", Locale.getDefault());
    private static final DateTimeFormatter DAY_FMT =
            DateTimeFormatter.ofPattern("dd", Locale.getDefault());

    private final List<Object> rows = new ArrayList<>();

    /** @param entries weigh-ins sorted newest-first */
    public LoggedWeightsAdapter(List<WeightEntry> entries) {
        YearMonth current = null;
        for (WeightEntry e : entries) {
            YearMonth ym = YearMonth.from(e.getDate());
            if (!ym.equals(current)) {
                rows.add(ym);
                current = ym;
            }
            rows.add(e);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return rows.get(position) instanceof YearMonth ? TYPE_MONTH : TYPE_ENTRY;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_MONTH) {
            return new MonthHolder(inf.inflate(R.layout.item_logged_month, parent, false));
        }
        return new EntryHolder(inf.inflate(R.layout.item_logged_weight, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Object row = rows.get(position);
        if (holder instanceof MonthHolder) {
            ((MonthHolder) holder).month.setText(((YearMonth) row).format(MONTH_FMT));
            return;
        }

        EntryHolder h = (EntryHolder) holder;
        WeightEntry e = (WeightEntry) row;
        Context c = h.itemView.getContext();
        LocalDate date = e.getDate();

        String fullDate = date.format(FULL_FMT);
        String weight = c.getString(R.string.unit_lbs, e.getWeight());

        h.weekday.setText(date.format(WEEKDAY_FMT));
        h.day.setText(date.format(DAY_FMT));
        h.fullDate.setText(fullDate);
        h.ago.setText(relative(c, date));
        h.weight.setText(weight);
        // Screen readers announce the row as one item: "Friday, October 2, 2026, 176.2 lbs"
        h.itemView.setContentDescription(c.getString(R.string.cd_logged_row, fullDate, weight));
    }

    /** "Today", "Yesterday", or "N days ago". */
    private static String relative(Context c, LocalDate date) {
        long days = ChronoUnit.DAYS.between(date, LocalDate.now());
        if (days <= 0) return c.getString(R.string.logged_today);
        if (days == 1) return c.getString(R.string.logged_yesterday);
        return c.getResources().getQuantityString(R.plurals.logged_days_ago, (int) days, (int) days);
    }

    @Override
    public int getItemCount() { return rows.size(); }

    static class MonthHolder extends RecyclerView.ViewHolder {
        final TextView month;
        MonthHolder(@NonNull View v) {
            super(v);
            month = v.findViewById(R.id.textMonth);
        }
    }

    static class EntryHolder extends RecyclerView.ViewHolder {
        final TextView weekday, day, fullDate, ago, weight;
        EntryHolder(@NonNull View v) {
            super(v);
            weekday = v.findViewById(R.id.textBadgeWeekday);
            day = v.findViewById(R.id.textBadgeDay);
            fullDate = v.findViewById(R.id.textFullDate);
            ago = v.findViewById(R.id.textAgo);
            weight = v.findViewById(R.id.textLoggedWeight);
        }
    }
}

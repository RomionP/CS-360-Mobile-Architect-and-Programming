package com.snhu.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Screen 3: asks for SEND_SMS permission and shows the result.
 * Granted  -> goal-reached texts are sent.
 * Denied   -> app keeps working, no notifications are sent.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    /** True when shown right after account creation (continue to the grid afterward). */
    public static final String EXTRA_ONBOARDING = "extra_onboarding";

    private boolean onboarding;
    private MaterialButton buttonEnable, buttonNotNow;
    private TextInputLayout layoutPhone;
    private TextInputEditText editPhone;

    /** System permission dialog; the callback updates the status card. */
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                SmsNotifier.setEnabledForUser(this, granted);
                renderStatus(granted ? Status.GRANTED : Status.DENIED);
            });

    private enum Status { UNKNOWN, GRANTED, DENIED, UNAVAILABLE }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Session.requireAccount(this)) return;
        setContentView(R.layout.activity_sms_permission);
        onboarding = getIntent().getBooleanExtra(EXTRA_ONBOARDING, false);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> leave());

        buttonEnable = findViewById(R.id.buttonEnableSms);
        buttonNotNow = findViewById(R.id.buttonNotNow);
        layoutPhone = findViewById(R.id.layoutPhone);
        editPhone = findViewById(R.id.editPhone);
        editPhone.setText(SmsNotifier.getPhone(this));

        buttonEnable.setOnClickListener(v -> onEnableClicked());

        // Entering the phone number and pressing Done on the keyboard brings up
        // the permission prompt right away (same as tapping Enable).
        editPhone.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (!(SmsNotifier.hasPermission(this) && SmsNotifier.isEnabledForUser(this))) {
                    onEnableClicked();
                }
                return true;
            }
            return false;
        });
        buttonNotNow.setOnClickListener(v -> {
            // "Not Now" turns texts off for this account only.
            SmsNotifier.setEnabledForUser(this, false);
            leave();
        });

        // Reflect the current state when the screen opens.
        if (!SmsNotifier.deviceCanSendSms(this)) {
            renderStatus(Status.UNAVAILABLE);
        } else if (SmsNotifier.hasPermission(this) && SmsNotifier.isEnabledForUser(this)) {
            // This account already said yes.
            renderStatus(Status.GRANTED);
        } else {
            renderStatus(Status.UNKNOWN);
        }
    }

    private void onEnableClicked() {
        if (SmsNotifier.hasPermission(this)) {
            if (SmsNotifier.isEnabledForUser(this)) {
                // This account is already set up: the button now continues.
                savePhoneIfValid();
                leave();
                return;
            }
            // The phone already allows SMS (another account said yes), so Android
            // won't show its pop-up again. Ask this account with the app's own pop-up.
            if (!savePhoneIfValid()) return;
            askInAppPermission();
            return;
        }
        if (!savePhoneIfValid()) return;
        // Check permission before sending anything; ask if we don't have it.
        requestSmsPermission.launch(Manifest.permission.SEND_SMS);
    }

    /** The app's own permission pop-up, used when Android's won't appear. */
    private void askInAppPermission() {
        new MaterialAlertDialogBuilder(this)
                .setIcon(R.drawable.ic_sms)
                .setTitle(R.string.settings_sms_ask_title)
                .setMessage(getString(R.string.settings_sms_ask_message, SmsNotifier.getPhone(this)))
                .setNegativeButton(R.string.settings_sms_ask_deny, (d, w) -> {
                    SmsNotifier.setEnabledForUser(this, false);
                    renderStatus(Status.DENIED);
                })
                .setPositiveButton(R.string.settings_sms_ask_allow, (d, w) -> {
                    SmsNotifier.setEnabledForUser(this, true);
                    renderStatus(Status.GRANTED);
                })
                .show();
    }

    private boolean savePhoneIfValid() {
        String phone = editPhone.getText() == null ? "" : editPhone.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            layoutPhone.setError(getString(R.string.error_phone_required));
            editPhone.requestFocus();
            return false;
        }
        layoutPhone.setError(null);
        SmsNotifier.savePhone(this, phone);
        return true;
    }

    private void renderStatus(Status status) {
        View screen = findViewById(android.R.id.content);
        switch (status) {
            case GRANTED:
                SmsStatus.show(screen, SmsStatus.State.ON);
                buttonEnable.setText(R.string.action_continue);
                buttonNotNow.setVisibility(View.GONE);
                break;
            case DENIED:
                SmsStatus.show(screen, SmsStatus.State.DENIED);
                buttonEnable.setText(R.string.action_enable_sms);
                buttonNotNow.setText(R.string.action_continue);
                break;
            case UNAVAILABLE:
                SmsStatus.show(screen, SmsStatus.State.UNAVAILABLE);
                buttonEnable.setEnabled(false);
                buttonNotNow.setText(R.string.action_continue);
                break;
            default:
                SmsStatus.show(screen, SmsStatus.State.NOT_SET_UP);
        }
    }

    private void leave() {
        if (onboarding) {
            startActivity(new Intent(this, WeightGridActivity.class));
        }
        finish();
    }
}

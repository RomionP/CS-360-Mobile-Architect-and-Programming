package com.snhu.weighttracker;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.text.TextUtils;

import androidx.core.content.ContextCompat;

/**
 * Sends the "goal weight reached" SMS.
 * Always checks the SEND_SMS permission first; if it was denied, nothing is sent
 * and the rest of the app keeps working normally.
 */
public final class SmsNotifier {

    private static final String PREFS = "sms_prefs";
    // Stored per account: "phone_<userId>" and "enabled_<userId>".
    private static final String KEY_PHONE = "phone_";
    private static final String KEY_ENABLED = "enabled_";

    private SmsNotifier() { }

    public static boolean deviceCanSendSms(Context c) {
        return c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY);
    }

    public static boolean hasPermission(Context c) {
        return ContextCompat.checkSelfPermission(c, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Saves the logged-in account's phone number (never for a guest). */
    public static void savePhone(Context c, String phone) {
        if (Session.isGuest()) return;
        prefs(c).edit().putString(KEY_PHONE + Session.userId(c), phone).apply();
    }

    /** The logged-in account's phone number ("" if none). */
    public static String getPhone(Context c) {
        return prefs(c).getString(KEY_PHONE + Session.userId(c), "");
    }

    /** Whether the logged-in account chose to receive goal texts. */
    public static boolean isEnabledForUser(Context c) {
        return prefs(c).getBoolean(KEY_ENABLED + Session.userId(c), false);
    }

    public static void setEnabledForUser(Context c, boolean enabled) {
        if (Session.isGuest()) return;
        prefs(c).edit().putBoolean(KEY_ENABLED + Session.userId(c), enabled).apply();
    }

    /** @return true if a message was sent. */
    public static boolean sendGoalReached(Context c, double goalWeight) {
        if (Session.isGuest()) return false;   // guests have no saved phone number
        String phone = getPhone(c);
        if (!deviceCanSendSms(c) || !hasPermission(c) || !isEnabledForUser(c)
                || TextUtils.isEmpty(phone)) {
            return false; // Denied, turned off for this account, or unavailable: no text.
        }
        try {
            smsManager(c).sendTextMessage(phone, null,
                    c.getString(R.string.sms_goal_message, goalWeight), null, null);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    private static SmsManager smsManager(Context c) {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? c.getSystemService(SmsManager.class)
                : SmsManager.getDefault();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}

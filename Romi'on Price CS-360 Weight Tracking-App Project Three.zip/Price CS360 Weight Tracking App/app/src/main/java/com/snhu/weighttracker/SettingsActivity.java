package com.snhu.weighttracker;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.EditorInfo;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Settings: turn goal-reached SMS texts on or off for the logged-in account.
 *
 * Turning OFF also asks Android to take back the SMS permission (Android 13+),
 * so turning it back ON shows Android's permission pop-up again. Android only
 * removes the permission once the app is closed, so if it is turned back on
 * before then, the app asks with its own permission pop-up instead.
 */
public class SettingsActivity extends AppCompatActivity {

    private MaterialSwitch switchSms;
    private TextInputLayout layoutPhone;
    private TextInputEditText editPhone;
    private View buttonOpenAppSettings;

    /** True while the code (not the user) is flipping the switch. */
    private boolean updatingSwitch = false;

    /**
     * Result of Android's pop-up, kept so onResume (which runs right after the
     * pop-up closes) shows it instead of overwriting it.
     */
    private SmsStatus.State pendingStatus = null;
    private boolean pendingShowSettingsButton = false;

    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    turnOn();
                } else {
                    // If Android won't show its pop-up anymore, offer the phone's settings.
                    boolean blocked = !shouldShowRequestPermissionRationale(Manifest.permission.SEND_SMS);
                    pendingStatus = blocked ? SmsStatus.State.BLOCKED : SmsStatus.State.DENIED;
                    pendingShowSettingsButton = blocked;
                    render();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Session.requireAccount(this)) return;
        setContentView(R.layout.activity_settings);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setSubtitle(Session.username(this));
        toolbar.setNavigationOnClickListener(v -> finish());

        switchSms = findViewById(R.id.switchSms);
        layoutPhone = findViewById(R.id.layoutSettingsPhone);
        editPhone = findViewById(R.id.editSettingsPhone);
        buttonOpenAppSettings = findViewById(R.id.buttonOpenAppSettings);

        editPhone.setText(SmsNotifier.getPhone(this));
        buttonOpenAppSettings.setOnClickListener(v -> openAppSettings());

        // Entering a phone number and pressing Done turns texts on, which brings
        // up the permission prompt (if they're already on, it just saves the number).
        editPhone.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId != EditorInfo.IME_ACTION_DONE) return false;
            if (switchSms.isChecked()) {
                savePhoneIfValid();
            } else if (switchSms.isEnabled()) {
                setSwitch(true);
                onTurnOnRequested();
            }
            return true;
        });

        switchSms.setOnCheckedChangeListener((button, isChecked) -> {
            if (updatingSwitch) return;
            if (isChecked) onTurnOnRequested(); else turnOff();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-check every time: the user may have changed it in the phone's settings.
        if (switchSms != null) render();
    }

    private void render() {
        boolean on = SmsNotifier.hasPermission(this) && SmsNotifier.isEnabledForUser(this);
        setSwitch(on);
        if (!SmsNotifier.deviceCanSendSms(this)) {
            switchSms.setEnabled(false);
            showStatus(SmsStatus.State.UNAVAILABLE);
        } else if (pendingStatus != null) {
            showStatus(pendingStatus);
        } else {
            showStatus(on ? SmsStatus.State.ON : SmsStatus.State.OFF);
        }
        buttonOpenAppSettings.setVisibility(pendingShowSettingsButton ? View.VISIBLE : View.GONE);
        pendingStatus = null;
        pendingShowSettingsButton = false;
    }

    private void onTurnOnRequested() {
        if (!savePhoneIfValid()) {
            setSwitch(false);
            return;
        }
        if (!SmsNotifier.hasPermission(this)) {
            // Android's own permission pop-up.
            requestSmsPermission.launch(Manifest.permission.SEND_SMS);
        } else {
            // Android still has the permission (it hasn't been taken back yet), so its
            // pop-up won't appear. Ask for permission with the app's own pop-up.
            new MaterialAlertDialogBuilder(this)
                    .setIcon(R.drawable.ic_sms)
                    .setTitle(R.string.settings_sms_ask_title)
                    .setMessage(getString(R.string.settings_sms_ask_message, SmsNotifier.getPhone(this)))
                    .setNegativeButton(R.string.settings_sms_ask_deny, (d, w) -> {
                        setSwitch(false);
                        showStatus(SmsStatus.State.DENIED);
                    })
                    .setPositiveButton(R.string.settings_sms_ask_allow, (d, w) -> turnOn())
                    .setOnCancelListener(d -> setSwitch(false))
                    .show();
        }
    }

    private void turnOn() {
        SmsNotifier.setEnabledForUser(this, true);
        setSwitch(true);
        showStatus(SmsStatus.State.ON);
        buttonOpenAppSettings.setVisibility(View.GONE);
    }

    private void turnOff() {
        SmsNotifier.setEnabledForUser(this, false);
        // Give the permission back to Android so it must be asked for again (Android 13+).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && SmsNotifier.hasPermission(this)) {
            revokeSelfPermissionOnKill(Manifest.permission.SEND_SMS);
        }
        showStatus(SmsStatus.State.TURNED_OFF);
    }

    private boolean savePhoneIfValid() {
        String phone = editPhone.getText() == null ? "" : editPhone.getText().toString().trim();
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.length() < 4) {
            layoutPhone.setError(getString(phone.isEmpty()
                    ? R.string.error_phone_required : R.string.error_phone_invalid));
            editPhone.requestFocus();
            return false;
        }
        layoutPhone.setError(null);
        SmsNotifier.savePhone(this, phone);
        return true;
    }

    private void openAppSettings() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", getPackageName(), null));
        startActivity(i);
    }

    private void setSwitch(boolean checked) {
        updatingSwitch = true;
        switchSms.setChecked(checked);
        updatingSwitch = false;
    }

    private void showStatus(SmsStatus.State state) {
        SmsStatus.show(findViewById(android.R.id.content), state);
    }
}

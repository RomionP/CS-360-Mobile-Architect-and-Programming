package com.snhu.weighttracker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;

import com.google.android.material.card.MaterialCardView;

/**
 * One look for every SMS permission message in the app.
 * Both the SMS screen and Settings show their status with the same card
 * (layout/view_sms_status.xml) and the same wording, colors and icons.
 */
public final class SmsStatus {

    public enum State {
        NOT_SET_UP (R.string.sms_state_not_set_up, R.drawable.ic_sms,   R.color.ink_600, R.color.teal_50),
        ON         (R.string.sms_state_on,         R.drawable.ic_check, R.color.success, R.color.teal_50),
        OFF        (R.string.sms_state_off,        R.drawable.ic_sms,   R.color.ink_600, R.color.teal_50),
        TURNED_OFF (R.string.sms_state_turned_off, R.drawable.ic_sms,   R.color.ink_600, R.color.teal_50),
        DENIED     (R.string.sms_state_denied,     R.drawable.ic_sms,   R.color.danger,  R.color.coral_100),
        BLOCKED    (R.string.sms_state_blocked,    R.drawable.ic_sms,   R.color.danger,  R.color.coral_100),
        UNAVAILABLE(R.string.sms_state_unavailable,R.drawable.ic_sms,   R.color.ink_600, R.color.divider);

        @StringRes final int text;
        @DrawableRes final int icon;
        @ColorRes final int tint;
        @ColorRes final int background;

        State(int text, int icon, int tint, int background) {
            this.text = text; this.icon = icon; this.tint = tint; this.background = background;
        }
    }

    private SmsStatus() { }

    /** Updates the status card found inside {@code screen} to show {@code state}. */
    public static void show(View screen, State state) {
        Context c = screen.getContext();
        MaterialCardView card = screen.findViewById(R.id.cardStatus);
        ImageView icon = screen.findViewById(R.id.imageStatus);
        TextView text = screen.findViewById(R.id.textStatus);

        text.setText(state.text);
        icon.setImageResource(state.icon);
        icon.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(c, state.tint)));
        card.setCardBackgroundColor(ContextCompat.getColor(c, state.background));

        // Same subtle fade everywhere so a change in status is noticeable.
        card.setAlpha(0f);
        card.animate().alpha(1f).setDuration(250).start();
    }
}

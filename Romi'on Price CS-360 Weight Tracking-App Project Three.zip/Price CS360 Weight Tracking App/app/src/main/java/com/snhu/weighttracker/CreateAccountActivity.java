package com.snhu.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Screen 1b: Create Account.
 * Saves a new username/password to UserDatabase, then continues to the
 * SMS permission screen and on to the dashboard.
 */
public class CreateAccountActivity extends AppCompatActivity {

    /** Optional username typed on the login screen, used to pre-fill this form. */
    public static final String EXTRA_USERNAME = "extra_username";

    static final int MIN_PASSWORD_LENGTH = 4;

    private TextInputLayout layoutUsername, layoutPassword, layoutConfirm;
    private TextInputEditText editUsername, editPassword, editConfirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        layoutUsername = findViewById(R.id.layoutNewUsername);
        layoutPassword = findViewById(R.id.layoutNewPassword);
        layoutConfirm = findViewById(R.id.layoutConfirmPassword);
        editUsername = findViewById(R.id.editNewUsername);
        editPassword = findViewById(R.id.editNewPassword);
        editConfirm = findViewById(R.id.editConfirmPassword);

        String prefill = getIntent().getStringExtra(EXTRA_USERNAME);
        if (!TextUtils.isEmpty(prefill)) {
            editUsername.setText(prefill);
            editPassword.requestFocus();
        }

        // "Done" on the last field submits this form (it never logs in).
        editConfirm.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) { createAccount(); return true; }
            return false;
        });

        findViewById(R.id.buttonSubmitAccount).setOnClickListener(v -> createAccount());
        findViewById(R.id.buttonHaveAccount).setOnClickListener(v -> finish());
    }

    private void createAccount() {
        layoutUsername.setError(null);
        layoutPassword.setError(null);
        layoutConfirm.setError(null);

        String username = editUsername.getText() == null ? "" : editUsername.getText().toString().trim();
        String password = raw(editPassword);
        String confirm = raw(editConfirm);

        if (TextUtils.isEmpty(username)) {
            showError(layoutUsername, editUsername, getString(R.string.error_username_required));
            return;
        }
        if (password.trim().isEmpty()) {
            showError(layoutPassword, editPassword, getString(R.string.error_password_required));
            return;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            showError(layoutPassword, editPassword,
                    getString(R.string.error_password_short, MIN_PASSWORD_LENGTH));
            return;
        }
        if (!password.equals(confirm)) {
            editConfirm.setText("");
            showError(layoutConfirm, editConfirm, getString(R.string.error_password_mismatch));
            return;
        }

        UserDatabase db = UserDatabase.get(this);
        UserDatabase.CreateResult result = db.createUser(username, password);
        if (result == UserDatabase.CreateResult.USERNAME_TAKEN) {
            showError(layoutUsername, editUsername, getString(R.string.error_username_taken));
            return;
        } else if (result == UserDatabase.CreateResult.ERROR) {
            Toast.makeText(this, R.string.error_account_not_saved, Toast.LENGTH_LONG).show();
            return;
        }

        // Log the new account in so its (empty) data is the one shown.
        Session.login(this, db.getUserId(username), username);
        Toast.makeText(this, getString(R.string.msg_account_created, username),
                Toast.LENGTH_SHORT).show();

        // New users see the SMS screen, then the dashboard. Clearing the task
        // means Back from there won't return to the login/sign-up screens.
        Intent i = new Intent(this, SmsPermissionActivity.class);
        i.putExtra(SmsPermissionActivity.EXTRA_ONBOARDING, true);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    /** Error under the field plus a pop-up, with the keyboard hidden so it's visible. */
    private void showError(TextInputLayout layout, TextInputEditText field, String message) {
        layout.setError(message);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(field.getWindowToken(), 0);
        field.requestFocus();
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private static String raw(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString();
    }
}

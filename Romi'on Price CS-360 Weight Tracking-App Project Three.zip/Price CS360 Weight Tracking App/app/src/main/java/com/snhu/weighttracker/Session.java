package com.snhu.weighttracker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Remembers which account is logged in, so every screen loads and saves
 * only that account's data. Survives the app being closed by the system.
 *
 * Guest mode is the exception: the guest flag is kept in memory only (never
 * in SharedPreferences), so a guest session and its data end when the guest
 * exits or Android closes the app.
 */
public final class Session {

    private static final String PREFS = "session";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USERNAME = "username";

    /** In memory only, on purpose: guest mode is never saved. */
    private static boolean guest = false;

    private Session() { }

    public static void login(Context c, long userId, String username) {
        endGuest();
        prefs(c).edit().putLong(KEY_USER_ID, userId).putString(KEY_USERNAME, username).apply();
    }

    /** Starts a fresh guest session with no account and nothing saved. */
    public static void startGuest(Context c) {
        prefs(c).edit().clear().apply();   // no account is active while a guest
        GuestStore.clear();
        guest = true;
    }

    public static boolean isGuest() {
        return guest;
    }

    public static void logout(Context c) {
        endGuest();
        prefs(c).edit().clear().apply();
    }

    private static void endGuest() {
        guest = false;
        GuestStore.clear();
    }

    /** @return the logged-in account's id, or -1 if nobody is logged in (or a guest). */
    public static long userId(Context c) {
        if (guest) return -1;
        return prefs(c).getLong(KEY_USER_ID, -1);
    }

    public static String username(Context c) {
        if (guest) return c.getString(R.string.guest_name);
        return prefs(c).getString(KEY_USERNAME, "");
    }

    /**
     * For screens that need a logged-in user or a guest: if there's neither,
     * sends the person to the login screen and returns false.
     */
    public static boolean requireLogin(Activity a) {
        if (guest || userId(a) != -1) return true;
        Intent i = new Intent(a, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        a.startActivity(i);
        a.finish();
        return false;
    }

    /**
     * For account-only screens (SMS and Settings save a phone number, so they
     * aren't available to guests). Returns false and closes the screen for a guest.
     */
    public static boolean requireAccount(Activity a) {
        if (!requireLogin(a)) return false;
        if (!guest) return true;
        a.finish();
        return false;
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}

package com.snhu.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Local SQLite database for accounts and each account's own weight data.
 *   users   : one row per account (salted SHA-256 password hash + goal weight)
 *   weights : weigh-ins, each tied to the user who logged it (user_id)
 * Every query that touches weights filters by user_id, so accounts never see
 * each other's data.
 */
public class UserDatabase extends SQLiteOpenHelper {

    private static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String COL_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_SALT = "salt";
    private static final String COL_HASH = "password_hash";
    private static final String COL_GOAL = "goal_weight";

    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_W_ID = "_id";
    private static final String COL_W_USER = "user_id";
    private static final String COL_W_DATE = "epoch_day";
    private static final String COL_W_WEIGHT = "weight";

    public static final double DEFAULT_GOAL = 170.0;

    public enum CreateResult { CREATED, USERNAME_TAKEN, ERROR }

    private static UserDatabase instance;

    public static synchronized UserDatabase get(Context context) {
        if (instance == null) instance = new UserDatabase(context.getApplicationContext());
        return instance;
    }

    private UserDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                + COL_SALT + " TEXT NOT NULL, "
                + COL_HASH + " TEXT NOT NULL, "
                + COL_GOAL + " REAL NOT NULL DEFAULT " + DEFAULT_GOAL + ")");
        createWeightsTable(db);
    }

    private static void createWeightsTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COL_W_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_W_USER + " INTEGER NOT NULL REFERENCES " + TABLE_USERS + "(" + COL_ID
                + ") ON DELETE CASCADE, "
                + COL_W_DATE + " INTEGER NOT NULL, "
                + COL_W_WEIGHT + " REAL NOT NULL)");
        db.execSQL("CREATE INDEX idx_weights_user ON " + TABLE_WEIGHTS
                + "(" + COL_W_USER + ", " + COL_W_DATE + ")");
    }

    /** Version 1 only had accounts: keep them and add the per-user data. */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COL_GOAL
                    + " REAL NOT NULL DEFAULT " + DEFAULT_GOAL);
            createWeightsTable(db);
        }
    }

    // ---------------------------------------------------------------- accounts

    public boolean userExists(String username) {
        return getUserId(username) != -1;
    }

    /** @return the account's id, or -1 if there is no such username. */
    public long getUserId(String username) {
        try (Cursor c = getReadableDatabase().query(TABLE_USERS, new String[]{COL_ID},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            return c.moveToFirst() ? c.getLong(0) : -1;
        }
    }

    /** Adds a new account unless the username is already taken. */
    public CreateResult createUser(String username, String password) {
        if (userExists(username)) return CreateResult.USERNAME_TAKEN;
        String salt = newSalt();
        ContentValues v = new ContentValues();
        v.put(COL_USERNAME, username);
        v.put(COL_SALT, salt);
        v.put(COL_HASH, hash(salt, password));
        long id = getWritableDatabase().insert(TABLE_USERS, null, v);
        return id == -1 ? CreateResult.ERROR : CreateResult.CREATED;
    }

    /** @return true only if the username exists and the password matches. */
    public boolean checkLogin(String username, String password) {
        try (Cursor c = getReadableDatabase().query(TABLE_USERS,
                new String[]{COL_SALT, COL_HASH},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            if (!c.moveToFirst()) return false;
            String salt = c.getString(0);
            String stored = c.getString(1);
            return MessageDigest.isEqual(
                    stored.getBytes(StandardCharsets.UTF_8),
                    hash(salt, password).getBytes(StandardCharsets.UTF_8));
        }
    }

    // ------------------------------------------------------------- goal weight

    public double getGoal(long userId) {
        try (Cursor c = getReadableDatabase().query(TABLE_USERS, new String[]{COL_GOAL},
                COL_ID + " = ?", new String[]{String.valueOf(userId)}, null, null, null)) {
            return c.moveToFirst() ? c.getDouble(0) : DEFAULT_GOAL;
        }
    }

    public void setGoal(long userId, double goal) {
        ContentValues v = new ContentValues();
        v.put(COL_GOAL, goal);
        getWritableDatabase().update(TABLE_USERS, v, COL_ID + " = ?",
                new String[]{String.valueOf(userId)});
    }

    // ----------------------------------------------------------------- weights

    /** This user's weigh-ins, newest first. */
    public List<WeightEntry> getWeights(long userId) {
        List<WeightEntry> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(TABLE_WEIGHTS,
                new String[]{COL_W_ID, COL_W_DATE, COL_W_WEIGHT},
                COL_W_USER + " = ?", new String[]{String.valueOf(userId)},
                null, null, COL_W_DATE + " DESC, " + COL_W_ID + " DESC")) {
            while (c.moveToNext()) {
                list.add(new WeightEntry(c.getLong(0), LocalDate.ofEpochDay(c.getLong(1)),
                        c.getDouble(2)));
            }
        }
        return list;
    }

    /** @return the new row's id (use it to build the WeightEntry), or -1 on failure. */
    public long addWeight(long userId, LocalDate date, double weight) {
        ContentValues v = new ContentValues();
        v.put(COL_W_USER, userId);
        v.put(COL_W_DATE, date.toEpochDay());
        v.put(COL_W_WEIGHT, weight);
        return getWritableDatabase().insert(TABLE_WEIGHTS, null, v);
    }

    /**
     * Changes the date and weight of one weigh-in, but only if it belongs to this user.
     * @return true if a row was updated.
     */
    public boolean updateWeight(long userId, long weightId, LocalDate date, double weight) {
        ContentValues v = new ContentValues();
        v.put(COL_W_DATE, date.toEpochDay());
        v.put(COL_W_WEIGHT, weight);
        int rows = getWritableDatabase().update(TABLE_WEIGHTS, v,
                COL_W_ID + " = ? AND " + COL_W_USER + " = ?",
                new String[]{String.valueOf(weightId), String.valueOf(userId)});
        return rows > 0;
    }

    /** Deletes one weigh-in, but only if it belongs to this user. */
    public void deleteWeight(long userId, long weightId) {
        getWritableDatabase().delete(TABLE_WEIGHTS,
                COL_W_ID + " = ? AND " + COL_W_USER + " = ?",
                new String[]{String.valueOf(weightId), String.valueOf(userId)});
    }

    // ----------------------------------------------------------------- helpers

    private static String newSalt() {
        byte[] b = new byte[16];
        new SecureRandom().nextBytes(b);
        return toHex(b);
    }

    private static String hash(String salt, String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt.getBytes(StandardCharsets.UTF_8));
            return toHex(md.digest(password.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }
}

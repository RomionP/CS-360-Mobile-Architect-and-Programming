package com.snhu.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.DateValidatorPointBackward;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Screen 2b: fields for adding a row to the weight grid, or for editing an
 * existing row. Edit mode is used when EXTRA_ENTRY_ID is passed in, along with
 * the row's current date and weight to pre-fill the form.
 * Returns the date, weight (and id, when editing) to WeightGridActivity, which
 * saves them to the database.
 */
public class AddWeightActivity extends AppCompatActivity {

    public static final String EXTRA_DATE_EPOCH_DAY = "extra_date_epoch_day";
    public static final String EXTRA_WEIGHT = "extra_weight";
    /** Id of the weigh-in being edited; absent (-1) when adding a new one. */
    public static final String EXTRA_ENTRY_ID = "extra_entry_id";

    private static final long NO_ID = -1;

    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.getDefault());

    private LocalDate selectedDate = LocalDate.now();
    private TextInputEditText editDate, editWeight;
    private TextInputLayout layoutWeight;
    private long entryId = NO_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        layoutWeight = findViewById(R.id.layoutWeight);
        TextInputLayout layoutDate = findViewById(R.id.layoutDate);

        // Edit mode: pre-fill the row's current values and relabel the screen.
        entryId = getIntent().getLongExtra(EXTRA_ENTRY_ID, NO_ID);
        if (entryId != NO_ID) {
            selectedDate = LocalDate.ofEpochDay(
                    getIntent().getLongExtra(EXTRA_DATE_EPOCH_DAY, LocalDate.now().toEpochDay()));
            double weight = getIntent().getDoubleExtra(EXTRA_WEIGHT, 0);
            editWeight.setText(String.format(Locale.US, "%.1f", weight));
            editWeight.setSelection(editWeight.length());
            toolbar.setTitle(R.string.title_edit_weight);
            ((TextView) findViewById(R.id.textAddHeading)).setText(R.string.edit_heading);
            ((TextView) findViewById(R.id.textAddSubheading)).setText(R.string.edit_subheading);
            ((MaterialButton) findViewById(R.id.buttonSave)).setText(R.string.action_save_changes);
        }

        editDate.setText(selectedDate.format(DATE_FMT));
        editDate.setOnClickListener(v -> showDatePicker());
        layoutDate.setEndIconOnClickListener(v -> showDatePicker());

        // Date defaults to today, so focus starts on the weight field.
        editWeight.requestFocus();
        editWeight.setOnEditorActionListener((v, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) { save(); return true; }
            return false;
        });

        findViewById(R.id.buttonSave).setOnClickListener(v -> save());
        findViewById(R.id.buttonCancel).setOnClickListener(v -> finish());
    }

    private void showDatePicker() {
        long selection = selectedDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();
        MaterialDatePicker<Long> picker = MaterialDatePicker.Builder.datePicker()
                .setTitleText(R.string.hint_date)
                .setSelection(selection)
                .setCalendarConstraints(new CalendarConstraints.Builder()
                        .setValidator(DateValidatorPointBackward.now()).build())
                .build();
        picker.addOnPositiveButtonClickListener(ms -> {
            selectedDate = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate();
            editDate.setText(selectedDate.format(DATE_FMT));
        });
        picker.show(getSupportFragmentManager(), "date");
    }

    private void save() {
        String raw = editWeight.getText() == null ? "" : editWeight.getText().toString().trim();
        if (TextUtils.isEmpty(raw)) {
            layoutWeight.setError(getString(R.string.error_weight_required));
            editWeight.requestFocus();
            return;
        }
        double weight;
        try {
            weight = Double.parseDouble(raw);
        } catch (NumberFormatException e) {
            layoutWeight.setError(getString(R.string.error_weight_required));
            return;
        }
        // Hand the values back; WeightGridActivity writes them to the database.
        Intent data = new Intent();
        data.putExtra(EXTRA_DATE_EPOCH_DAY, selectedDate.toEpochDay());
        data.putExtra(EXTRA_WEIGHT, weight);
        data.putExtra(EXTRA_ENTRY_ID, entryId);
        setResult(RESULT_OK, data);
        finish();
    }
}
